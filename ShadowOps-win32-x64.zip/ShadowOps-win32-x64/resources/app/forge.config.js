/* eslint-disable quotes */
module.exports = {
  makers: [
    {
      name: '@electron-forge/maker-squirrel',
      config: {
        authors: 'YOU',
        description: 'Multiplayer Shooter',
        exe: `shadowOps.exe`,
        name: `shadow ops`,
      },
    },
  ],
};
